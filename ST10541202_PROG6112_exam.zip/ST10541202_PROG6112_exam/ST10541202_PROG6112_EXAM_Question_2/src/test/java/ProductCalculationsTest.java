package com.mycompany.st10541202_prog6112_exam_question_2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductCalculationsTest {

    /**
     * Purpose: Verify that the GetVat method in the ProductCalculations
     * class correctly returns the VAT amount (15% of product price).
     */
    @Test
    public void GetVat_WithValidData_ReturnsCorrectValue() {
        // Arrange
        double price = 1000.00;
        ProductCalculations calc = new ProductCalculations(price);
        double expectedVat = 150.00;   // 15% of 1000

        // Act
        double actualVat = calc.GetVat();

        // Assert
        assertEquals(expectedVat, actualVat, 0.001,
                "VAT should be 15% of the product price");
    }

    /**
     * Purpose: Verify that the GetTotal method in the ProductCalculations
     * class correctly returns the Total Sale Amount
     * (Price + VAT + Commission).
     */
    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {
        // Arrange
        double price = 1000.00;
        ProductCalculations calc = new ProductCalculations(price);
        // Expected: 1000 + 150 (VAT) + 50 (Commission) = 1200
        double expectedTotal = 1200.00;

        // Act
        double actualTotal = calc.GetTotal();

        // Assert
        assertEquals(expectedTotal, actualTotal, 0.001,
                "Total should equal Price + VAT + Commission");
    }
}