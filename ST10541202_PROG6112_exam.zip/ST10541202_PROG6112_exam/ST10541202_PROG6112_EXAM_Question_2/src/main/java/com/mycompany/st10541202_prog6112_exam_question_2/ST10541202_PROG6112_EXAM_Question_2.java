package com.mycompany.st10541202_prog6112_exam_question_2;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

// ============================================================
// INTERFACE: IProductCalculations
// ============================================================
interface IProductCalculations {
    double GetVat();
    double GetCommision();
    double GetTotal();
}

// ============================================================
// CLASS: ProductCalculations
// ============================================================
class ProductCalculations implements IProductCalculations {

    private double productPrice;

    private static final double VAT_RATE = 0.15;
    private static final double COMMISSION_RATE = 0.05;

    public ProductCalculations(double productPrice) {
        this.productPrice = productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    public double getProductPrice() {
        return productPrice;
    }

    @Override
    public double GetVat() {
        return productPrice * VAT_RATE;
    }

    @Override
    public double GetCommision() {
        return productPrice * COMMISSION_RATE;
    }

    @Override
    public double GetTotal() {
        return productPrice + GetVat() + GetCommision();
    }
}

// ============================================================
// MAIN GUI CLASS
// ============================================================
public class ST10541202_PROG6112_EXAM_Question_2 extends JFrame {

    private JTextField txtCustomerName;
    private JTextField txtProductPrice;
    private JComboBox<String> cmbProductName;

    private JTextField txtVat;
    private JTextField txtCommission;
    private JTextField txtTotalSale;

    private JButton btnProcess;
    private JButton btnClear;

    private JMenuItem miExit;
    private JMenuItem miProcess;
    private JMenuItem miClear;

    private final String[] PRODUCTS = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
    };

    public ST10541202_PROG6112_EXAM_Question_2() {
        setTitle("Mattress Sales Manager");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        buildMenu();
        buildForm();

        setVisible(true);
    }

    private void buildMenu() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        miExit = new JMenuItem("Exit");
        miExit.addActionListener(e -> System.exit(0));
        fileMenu.add(miExit);

        JMenu toolsMenu = new JMenu("Tools");
        miProcess = new JMenuItem("Process");
        miClear = new JMenuItem("Clear");

        miProcess.addActionListener(e -> processSale());
        miClear.addActionListener(e -> clearForm());

        toolsMenu.add(miProcess);
        toolsMenu.add(miClear);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
    }

    private void buildForm() {
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        formPanel.add(new JLabel("Customer Name:"));
        txtCustomerName = new JTextField();
        formPanel.add(txtCustomerName);

        formPanel.add(new JLabel("Product Name:"));
        cmbProductName = new JComboBox<>(PRODUCTS);
        formPanel.add(cmbProductName);

        formPanel.add(new JLabel("Product Price:"));
        txtProductPrice = new JTextField();
        formPanel.add(txtProductPrice);

        formPanel.add(new JLabel("VAT Amount (15%):"));
        txtVat = new JTextField();
        txtVat.setEditable(false);
        formPanel.add(txtVat);

        formPanel.add(new JLabel("Commission Amount (5%):"));
        txtCommission = new JTextField();
        txtCommission.setEditable(false);
        formPanel.add(txtCommission);

        formPanel.add(new JLabel("Total Sale Amount:"));
        txtTotalSale = new JTextField();
        txtTotalSale.setEditable(false);
        formPanel.add(txtTotalSale);

        add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnProcess = new JButton("Process");
        btnClear = new JButton("Clear");

        btnProcess.addActionListener(e -> processSale());
        btnClear.addActionListener(e -> clearForm());

        buttonPanel.add(btnProcess);
        buttonPanel.add(btnClear);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void processSale() {
        String customerName = txtCustomerName.getText().trim();
        String productName = (String) cmbProductName.getSelectedItem();
        String priceText = txtProductPrice.getText().trim();

        if (customerName.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter the customer's name.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (priceText.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter the product price.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceText);
            if (price < 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a valid positive number for the product price.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        ProductCalculations calc = new ProductCalculations(price);
        double vat = calc.GetVat();
        double commission = calc.GetCommision();
        double total = calc.GetTotal();

        txtVat.setText(String.format("%.2f", vat));
        txtCommission.setText(String.format("%.2f", commission));
        txtTotalSale.setText(String.format("%.2f", total));

        saveToFile(customerName, productName, price, vat, commission, total);

        JOptionPane.showMessageDialog(this,
                "Sale processed and saved to data.txt successfully.",
                "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void saveToFile(String customerName, String productName,
                            double price, double vat, double commission, double total) {
        String timestamp = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        try (PrintWriter writer = new PrintWriter(new FileWriter("data.txt", true))) {
            writer.println("========================================");
            writer.println("Date/Time       : " + timestamp);
            writer.println("Customer Name   : " + customerName);
            writer.println("Product Name    : " + productName);
            writer.printf("Product Price   : R %.2f%n", price);
            writer.printf("VAT (15%%)       : R %.2f%n", vat);
            writer.printf("Commission (5%%) : R %.2f%n", commission);
            writer.printf("Total Sale      : R %.2f%n", total);
            writer.println("========================================");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                    "Error saving to file: " + e.getMessage(),
                    "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearForm() {
        txtCustomerName.setText("");
        txtProductPrice.setText("");
        txtVat.setText("");
        txtCommission.setText("");
        txtTotalSale.setText("");
        cmbProductName.setSelectedIndex(0);
        txtCustomerName.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ST10541202_PROG6112_EXAM_Question_2());
    }
}