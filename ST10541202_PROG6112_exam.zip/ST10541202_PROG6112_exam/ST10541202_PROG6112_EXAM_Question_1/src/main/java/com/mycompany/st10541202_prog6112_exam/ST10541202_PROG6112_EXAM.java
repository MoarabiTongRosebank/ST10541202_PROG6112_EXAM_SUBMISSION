package com.mycompany.st10541202_prog6112_exam;

import java.util.Scanner;

public class ST10541202_PROG6112_EXAM {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // --- Get number of products ---
        System.out.print("How many products? ");
        int numProducts = Integer.parseInt(scanner.nextLine().trim());

        // --- Get product names ---
        String[] products = new String[numProducts];
        for (int i = 0; i < numProducts; i++) {
            System.out.print("Enter name for product " + (i + 1) + ": ");
            products[i] = scanner.nextLine().trim();
        }

        // --- Get number of months ---
        System.out.print("How many months of sales data? ");
        int numMonths = Integer.parseInt(scanner.nextLine().trim());

        // --- Get sales data: loop by product, then by month ---
        // sales[productIndex][monthIndex]
        int[][] sales = new int[numProducts][numMonths];
        for (int p = 0; p < numProducts; p++) {
            System.out.println();
            for (int m = 0; m < numMonths; m++) {
                System.out.print("Enter the number of sales for month " + (m + 1)
                        + " for " + products[p] + ": ");
                sales[p][m] = Integer.parseInt(scanner.nextLine().trim());
            }
        }

        // --- Run logic ---
        Product product = new Product(products, sales);
        PrintProduct printer = new PrintProduct();

        System.out.println();
        printer.printTotalProductSales(product.getTotalProductsSold());
        printer.printAverageProductSales(product.getAverageProductSold());
        printer.printMostPopularSale(product.getMostPopularProduct());

        scanner.close();
    }
}

interface IProducts {
    int getTotalProductsSold();
    double getAverageProductSold();
    String getMostPopularProduct();
}

class Product implements IProducts {
    private final String[] products;
    private final int[][] sales;   // sales[productIndex][monthIndex]

    public Product(String[] products, int[][] sales) {
        this.products = products;
        this.sales = sales;
    }

    @Override
    public int getTotalProductsSold() {
        int total = 0;
        for (int[] productSales : sales)
            for (int qty : productSales) total += qty;
        return total;
    }

    @Override
    public double getAverageProductSold() {
        return (double) getTotalProductsSold() / products.length;
    }

    @Override
    public String getMostPopularProduct() {
        int[] totals = new int[products.length];
        for (int p = 0; p < sales.length; p++)
            for (int m = 0; m < sales[p].length; m++) totals[p] += sales[p][m];
        int max = 0;
        for (int i = 1; i < totals.length; i++) if (totals[i] > totals[max]) max = i;
        return products[max];
    }
}

class PrintProduct {
    public void printTotalProductSales(int total) {
        System.out.println("Total Products Sold: " + total);
    }

    public void printAverageProductSales(double average) {
        System.out.printf("Average Products Sold per Product: %.2f%n", average);
    }

    public void printMostPopularSale(String product) {
        System.out.println("Most Popular Product: " + product);
    }
}

class ProductTest {
    static void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {
        Product p = new Product(
            new String[]{"Memory Foam", "Spring", "Hybrid"},
            new int[][]{{10, 20, 30}, {40, 50, 60}, {70, 80, 90}});
        int expected = 450;
        System.out.println("Test 1: " + (p.getTotalProductsSold() == expected ? "PASSED" : "FAILED"));
    }

    static void GetAverageSales_WithValidData_ReturnsCorrectValue() {
        Product p = new Product(
            new String[]{"Memory Foam", "Spring", "Hybrid"},
            new int[][]{{10, 20, 30}, {40, 50, 60}, {70, 80, 90}});
        double expected = 150.0;
        System.out.println("Test 2: " + (Math.abs(p.getAverageProductSold() - expected) < 0.001 ? "PASSED" : "FAILED"));
    }

    public static void main(String[] args) {
        GetTotalProductSales_WithValidData_ReturnsCorrectValue();
        GetAverageSales_WithValidData_ReturnsCorrectValue();
    }
}