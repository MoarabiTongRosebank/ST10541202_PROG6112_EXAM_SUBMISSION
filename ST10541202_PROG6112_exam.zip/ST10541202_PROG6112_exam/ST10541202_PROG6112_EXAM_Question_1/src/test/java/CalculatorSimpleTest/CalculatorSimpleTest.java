import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CalculatorSimpleTest {

    private Product product;

    @BeforeEach
    public void setUp() {
        product = new Product(new int[]{10, 20, 30});
    }

    @Test
    public void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {
        assertEquals(60, product.GetTotalProductsSold());
    }

    @Test
    public void GetAverageSales_WithValidData_ReturnsCorrectValue() {
        assertEquals(20.0, product.GetAverageSales(), 0.001);
    }
}

class Product {

    private final int[] sales;

    public Product(int[] sales) {
        this.sales = sales;
    }

    public int GetTotalProductsSold() {
        int total = 0;
        for (int s : sales) total += s;
        return total;
    }

    public double GetAverageSales() {
        if (sales == null || sales.length == 0) return 0;
        return (double) GetTotalProductsSold() / sales.length;
    }
}